from flask import Flask, render_template, request
import os
from werkzeug.utils import secure_filename
from ultralytics import YOLO

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
model = YOLO('yolov8n.pt')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_image():
    file = request.files['file']
    if file:
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        results = model(file_path)
        results[0].save(filename=True, save_dir=app.config['UPLOAD_FOLDER'])

        result_filename = results[0].path.split('/')[-1]
        result_path = f"{app.config['UPLOAD_FOLDER']}/{result_filename}"
        count = len(results[0].boxes.cls)

        return render_template('result.html', image_path=result_path, count=count)
    return "No file uploaded"

if __name__ == '__main__':
    app.run()
